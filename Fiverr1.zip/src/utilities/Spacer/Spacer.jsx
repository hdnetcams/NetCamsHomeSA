import classes from '../ScrollToTop/Misc.module.css';

function Spacer() {
  return <div className={classes['spacer']} />;
}

export default Spacer;
