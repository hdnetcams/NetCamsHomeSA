import { createContext } from 'react';

const navbarContext = createContext();

export default navbarContext;
